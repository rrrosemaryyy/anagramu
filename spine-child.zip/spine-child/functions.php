<?php // Opening PHP tag - nothing should be before this, not even whitespace

/*
Unlike style.css, the functions.php of a child theme does not override its counterpart from the parent. Instead, it is loaded in addition to the parent’s functions.php.
*/

/* this is a function that has not been overwritten by Spine */
function spinecat_clientname_excerpt_length( $length ) {
    return 50;
}
add_filter( 'excerpt_length', 'spinecat_clientname_excerpt_length' );

/* This is a function that has been overwritten, so we have to remove it before adding in our own */
/* http://codex.wordpress.org/Plugin_API/Filter_Reference/excerpt_more */
/* http://stackoverflow.com/questions/10081129/why-cant-i-override-wps-excerpt-more-filter-via-my-child-theme-functions */

/*
add_action( 'after_setup_theme', 'childtheme_setup' );

if ( ! function_exists( 'childtheme_setup' ) ):

function childtheme_setup() {

    // OVERRIDE : EXCERPT READ MORE LINK FUNCTION
    remove_filter( 'excerpt_more', 'spine2_new_excerpt_more' );

    function spinecat_new_excerpt_more($more) {
			global $post;
			return '<a class="moretag" href="'. get_permalink($post->ID) . '"> Read the full meowmeow...</a>';
		}

		add_filter('excerpt_more', 'spinecat_new_excerpt_more');

}
endif; // childtheme_setup
*/
